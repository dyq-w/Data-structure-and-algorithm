public class Li1_1
{
	public static void main(String[] args)
	{
	int sum;
	int i=5;
	int j=3;
	sum=i+j;
	System.out.println("first digit:"+i);
	System.out.println("second digit:"+j);
	System.out.println("the sum of two digit:"+sum);
	}
}
